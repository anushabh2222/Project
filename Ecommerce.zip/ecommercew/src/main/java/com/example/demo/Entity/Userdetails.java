package com.example.demo.Entity;

import javax.persistence.*;

@Entity
public class Userdetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public String emailId;

    public String password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Userdetails() {
    }

    /*
     * public Userdetails(int id, String username, String password) { this.id = id;
     * this.username = username; this.password = password; }
     */

}
