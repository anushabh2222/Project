package com.example.demo.Entity;
import javax.persistence.*;

@Entity(name="pro")
public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int productid;
    String name;
   // String bookdesc;
    String img;
    Double prize;

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	//public String getBookdesc() {
		//return bookdesc;
	//}

	//public void setBookdesc(String bookdesc) {
	//	this.bookdesc = bookdesc;
	//}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public Double getPrize() {
		return prize;
	}

	public void setPrize(Double prize) {
		this.prize = prize;
	}

}
