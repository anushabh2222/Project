/*
 * package com.example.demo.Model;
 * 
 * import com.example.demo.Entity.Cart_item; import
 * com.example.demo.Entity.Product; import
 * com.example.demo.Repoistory.Cart_itemRepository; import
 * com.example.demo.Repoistory.ProductRepository;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * public class Cart { public void addToCart(Long book_id, Cart_item cart_item,
 * String name) { Product product; product =
 * ProductRepository.findById(book_id).orElse(null);
 * Cart_item.setProduct(product);
 * Cart_item.setSubtotal(product.getBook_price()); Cart_item.setName(name);
 * Cart_itemRepository.save(cart_item); } //public List<Cart_item> mycart(String
 * name){ List<Cart_item>cart_item=new ArrayList<>();
 * Cart_itemRepository.findByusername(name).forEach(cart_item::add()); return
 * cart_item; }
 * 
 * }
 */
