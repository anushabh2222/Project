let namenode=document.getElementById("name");
let spannode1=document.getElementById("error1");
function validate8(){
    spannode8.innerHTML="";
    let name=namenode.value;
    
    if(name=='')
    {
    spannode8.innerHTML="This Field is required";
    namenode.style.border="3px solid red";
    return false;
    }
    else if(name.includes(' '))
    {
    spannode8.innerHTML="Space is not allowed";
    namenode.style.border="3px solid dark red";
    return false;
    }
    else
    {
        namenode.style.border="3px solid green";
        return true;
    }
}
//Password
let passnode=document.getElementById("pass");
let spannode2=document.getElementById("error3");
function validate2(){
    spannode2.innerHTML="";
    let password=passnode.value;
    let regExp = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
    console.log(password);
    console.log(regExp.test(password));
    
    if(password==' ')
    {
    spannode2.innerHTML="This Field is required";
    passnode.style.border="3px solid red";
    return false;
    }
    else if(password.length<4 || password.length<6)
    {
    spannode2.innerHTML="Password should be 4 to 6 character long";
    passnode.style.border="3px solid red";
    return false;
    }

    else if(regExp.test(password)==false){
        spannode2.innerHTML="Password should be alphanumeric with special symbol";
        passnode.style.border="3px solid red";
        return false;
    }
    else
    {
        passnode.style.border="3px solid green";
        return true;
    }
}
//Confirm_password
let c_passnode=document.getElementById("c_pass");
let spannode3=document.getElementById("error4");
function validate3(){
    spannode3.innerHTML="";
    let password=passnode.value;
    let c_password=c_passnode.value; 
    if(c_password=='')
    {
    spannode3.innerHTML="This Field is required";
    c_passnode.style.border="3px solid red";
    return false;
    }
    else if(c_password!=password)
    {
    spannode3.innerHTML="Password should match";
    c_passnode.style.border="3px solid dark red";
    return false;
    }

    else
    {
        c_passnode.style.border="3px solid green";
        return true;
    }
}
//Email_id

let emailnode=document.getElementById("mail");
let spannode4=document.getElementById("error5");
function validate4(){
    spannode4.innerHTML="";
    let emailid=emailnode.value;
    let subs=emailid.substring(emailid.indexOf('@')+1);
    
    if(emailid=='')
    {
    spannode4.innerHTML="This Field is required";
    emailnode.style.border="3px solid red";
    return false;
    }
    else if(!emailid.includes('@') || subs=='')
    {
    spannode4.innerHTML="Invalid EmailId";
    emailnode.style.border="3px solid red";
    return false;
    }
    else
    {
        emailnode.style.border="4px solid green";
        return true;
    }
}
let phonenode=document.getElementById("phone");
let spannode5=document.getElementById("error7");
function validate5(){

    spannode5.innerHTML="";
    let phone=phonenode.value;
   // let var1=parseInt(phone);
    if(phone=='')
    {
        spannode5.innerHTML="This field is required";
        phonenode.style.border="3px solid red";
        return false;
    }

    else if(phone.length<10 || phone.length>10)
    {
        spannode5.innerHTML="Enter valid phone no.";
        phonenode.style.border="3px solid red";
        return false;

    }
    else if(phone.includes(' '))
    {
        spannode5.innerHTML="Enter valid phone no.";
        phonenode.style.border="3px solid red";
        return false;

    }
    else if(isNaN(phone))
    {
        spannode5.innerHTML="Enter 0-9 digits only";
        phonenode.style.border="3px solid red";
        return false;
    }
    
   
    else
    {
        phonenode.style.border="3px solid green";
        return true;
    }

}
function validateform(){
    let v1=validate1();  //Valid then return true else return false
    let v2=validate2();    //Valid then return true else return false
    let v3=validate3();     //Valid then return true else return false
    let v4=validate4();     //Valid then return true else return false
    let v5=validate5();      //Valid then return true else return false
    //let v6=validate6();       //Valid then return true else return false

    if(v1==true && v2==true && v3==true && v4==true && v5==true)
    //(or) if(v1&&v2&&v3&&v4&&v5&&v6&&v7)
    return true;
    else
    return false;

}
